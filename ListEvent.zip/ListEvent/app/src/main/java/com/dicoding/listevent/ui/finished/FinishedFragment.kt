package com.dicoding.listevent.ui.finished

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.listevent.DetailActivity
import com.dicoding.listevent.ListEventsAdapter
import com.dicoding.listevent.databinding.FragmentFinishedBinding

class FinishedFragment : Fragment() {

    private var _binding: FragmentFinishedBinding? = null
    private val binding get() = _binding!!

    private lateinit var eventAdapter: ListEventsAdapter

    private val finishedViewModel: FinishedViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFinishedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize RecyclerView dan adapter
        eventAdapter = ListEventsAdapter { event ->
            val intent = Intent(requireContext(), DetailActivity::class.java).apply {
                putExtra("EVENT_DETAIL", event) // Kirim event sebagai Parcelable
            }
            startActivity(intent)
        }

        binding.rvEvents.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = eventAdapter
        }

        // Observe LiveData dari ViewModel
        finishedViewModel.events.observe(viewLifecycleOwner) { events ->
            eventAdapter.submitList(events)
            if (events.isNullOrEmpty()) {
                binding.textNoData.visibility =
                    View.VISIBLE // Tampilkan pesan "Data tidak tersedia"
                binding.rvEvents.visibility = View.GONE      // Sembunyikan RecyclerView
            } else {
                binding.textNoData.visibility = View.GONE    // Sembunyikan pesan
                binding.rvEvents.visibility = View.VISIBLE   // Tampilkan RecyclerView
            }
        }

        finishedViewModel.loading.observe(viewLifecycleOwner) { isLoading ->
            showLoading(isLoading)
        }

        finishedViewModel.error.observe(viewLifecycleOwner) { errorMessage ->
            if (errorMessage != null) {
                Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_LONG).show()
            }
        }

        // Setup search feature
        binding.searchView.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    finishedViewModel.searchEvents(query)
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

        // Panggil API untuk memuat events jika belum ada data
        if (finishedViewModel.events.value == null) {
            finishedViewModel.loadFinishedEvents()
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
