package com.dicoding.listevent

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("/events?active=1")
    fun getUpcoming(): Call<EventResponse>

    @GET("/events?active=0")
    fun getFinish(): Call<EventResponse>

    @GET("/events")
    fun searchEvents(
        @Query("q") query: String
    ): Call<EventResponse>

}
