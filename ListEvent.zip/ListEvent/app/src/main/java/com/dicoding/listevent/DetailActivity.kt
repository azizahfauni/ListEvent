package com.dicoding.listevent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.dicoding.listevent.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Tampilkan ProgressBar saat data sedang dimuat
        binding.progressBar.visibility = View.VISIBLE

        // Terima data dari Intent
        val event = intent.getParcelableExtra<ListEventsItem>("EVENT_DETAIL")

        event?.let {
            // Tampilkan data
            binding.tvEventName.text = it.name
            binding.tvOwnerName.text = it.ownerName
            binding.tvEventTime.text = it.beginTime
            binding.tvRemainingQuota.text = (it.quota - it.registrants).toString()
            binding.tvEventDescription.text = HtmlCompat.fromHtml(it.description, HtmlCompat.FROM_HTML_MODE_LEGACY)

            // Muat gambar dengan Glide
            Glide.with(this)
                .load(it.mediaCover)
                .into(binding.ivEventImage)

            // Atur tombol untuk membuka link
            binding.btnOpenLink.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(event.link))
                startActivity(intent)
            }

            // Sembunyikan ProgressBar setelah data ditampilkan
            binding.progressBar.visibility = View.GONE

        } ?: run {
            Log.e("DetailActivity", "Data event adalah null")
            // Sembunyikan ProgressBar jika tidak ada data
            binding.progressBar.visibility = View.GONE
        }
    }
}
